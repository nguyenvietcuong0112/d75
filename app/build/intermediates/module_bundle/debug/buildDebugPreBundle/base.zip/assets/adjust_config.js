function AdjustConfig(appToken, environment, legacy) {
    this.allowSuppressLogLevel = null;

    if (arguments.length === 2) {
        // new format does not require bridge as first parameter
        this.appToken = appToken;
        this.environment = environment;
    } else if (arguments.length === 3) {
        // new format with allowSuppressLogLevel
        if (typeof(legacy) == typeof(true)) {
            this.appToken = appToken;
            this.environment = environment;
            this.allowSuppressLogLevel = legacy;
        } else {
            // old format with first argument being the bridge instance
            this.bridge = appToken;
            this.appToken = environment;
            this.environment = legacy;
        }
    }

    this.isSendingInBackgroundEnabled = null;
    this.logLevel = null;
    this.sdkPrefix = null;
    this.processName = null;
    this.defaultTracker = null;
    this.externalDeviceId = null;
    this.attributionCallbackName = null;
    this.attributionCallbackFunction = null;
    this.thirdPartySharingSettingsChangedCallbackName = null;
    this.thirdPartySharingSettingsChangedCallbackFunction = null;
    this.isCostDataInAttributionEnabled = null;
    this.eventSuccessCallbackName = null;
    this.eventSuccessCallbackFunction = null;
    this.eventFailureCallbackName = null;
    this.eventFailureCallbackFunction = null;
    this.sessionSuccessCallbackName = null;
    this.sessionSuccessCallbackFunction = null;
    this.sessionFailureCallbackName = null;
    this.sessionFailureCallbackFunction = null;
    this.isOpeningDeferredDeeplinkEnabled = null;
    this.deferredDeeplinkCallbackName = null;
    this.deferredDeeplinkCallbackFunction = null;
    this.remoteTriggerCallbackName = null;
    this.remoteTriggerCallbackFunction = null;
    this.fbPixelDefaultEventToken = null;
    this.fbPixelMapping = [];
    this.urlStrategyDomains = [];
    this.useSubdomains = null;
    this.isDataResidency = null;
    this.isPreinstallTrackingEnabled = null;
    this.preinstallFilePath = null;
    this.coppaComplianceEnabled = null;
    this.playStoreKidsComplianceEnabled = null;
    this.fbAppId = null;
    this.shouldReadDeviceIdsOnce = null;
    this.eventDeduplicationIdsMaxSize = null;
    this.isFirstSessionDelayEnabled = null;
    this.storeInfo = null;
    this.isGoogleAdIdReadingEnabled = null;
    this.isAndroidIdReadingEnabled = null;
    this.isAppSetIdReadingEnabled = null;
    this.isFbIdReadingEnabled = null;
    this.isFireAdIdReadingEnabled = null;
    this.isDeviceIdsFromPluginsReadingEnabled = null;
}

AdjustConfig.EnvironmentSandbox = 'sandbox';
AdjustConfig.EnvironmentProduction = 'production';

AdjustConfig.LogLevelVerbose = 'VERBOSE',
AdjustConfig.LogLevelDebug = 'DEBUG',
AdjustConfig.LogLevelInfo = 'INFO',
AdjustConfig.LogLevelWarn = 'WARN',
AdjustConfig.LogLevelError = 'ERROR',
AdjustConfig.LogLevelAssert = 'ASSERT',
AdjustConfig.LogLevelSuppress = 'SUPPRESS',

AdjustConfig.prototype.getBridge = function() {
    return this.bridge;
};

AdjustConfig.prototype.enableSendingInBackground = function() {
    this.isSendingInBackgroundEnabled = true;
};

AdjustConfig.prototype.setLogLevel = function(logLevel) {
    this.logLevel = logLevel;
};

AdjustConfig.prototype.getSdkPrefix = function() {
    return this.sdkPrefix;
};

AdjustConfig.prototype.setSdkPrefix = function(sdkPrefix) {
    this.sdkPrefix = sdkPrefix;
};

AdjustConfig.prototype.setProcessName = function(processName) {
    this.processName = processName;
};

AdjustConfig.prototype.setDefaultTracker = function(defaultTracker) {
    this.defaultTracker = defaultTracker;
};

AdjustConfig.prototype.setExternalDeviceId = function(externalDeviceId) {
    this.externalDeviceId = externalDeviceId;
};

AdjustConfig.prototype.setAttributionCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.attributionCallbackName = callback;
    } else {
        this.attributionCallbackName = 'Adjust.getConfig().adjust_attributionCallback';
        this.attributionCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_attributionCallback = function(attribution) {
    if (this.attributionCallbackFunction) {
        this.attributionCallbackFunction(attribution);
    }
};

AdjustConfig.prototype.setThirdPartySharingSettingsChangedCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.thirdPartySharingSettingsChangedCallbackName = callback;
    } else {
        this.thirdPartySharingSettingsChangedCallbackName = 'Adjust.getConfig().adjust_thirdPartySharingSettingsChangedCallback';
        this.thirdPartySharingSettingsChangedCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_thirdPartySharingSettingsChangedCallback = function(result) {
    if (this.thirdPartySharingSettingsChangedCallbackFunction) {
        this.thirdPartySharingSettingsChangedCallbackFunction(result);
    }
};

AdjustConfig.prototype.enableCostDataInAttribution = function() {
    this.isCostDataInAttributionEnabled = true;
};

AdjustConfig.prototype.setEventSuccessCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.eventSuccessCallbackName = callback;
    } else {
        this.eventSuccessCallbackName = 'Adjust.getConfig().adjust_eventSuccessCallback';
        this.eventSuccessCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_eventSuccessCallback = function(eventSuccess) {
    if (this.eventSuccessCallbackFunction) {
        this.eventSuccessCallbackFunction(eventSuccess);
    }
};

AdjustConfig.prototype.setEventFailureCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.eventFailureCallbackName = callback;
    } else {
        this.eventFailureCallbackName = 'Adjust.getConfig().adjust_eventFailureCallback';
        this.eventFailureCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_eventFailureCallback = function(eventFailure) {
    if (this.eventFailureCallbackFunction) {
        this.eventFailureCallbackFunction(eventFailure);
    }
};

AdjustConfig.prototype.setSessionSuccessCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.sessionSuccessCallbackName = callback;
    } else {
        this.sessionSuccessCallbackName = 'Adjust.getConfig().adjust_sessionSuccessCallback';
        this.sessionSuccessCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_sessionSuccessCallback = function(sessionSuccess) {
    if (this.sessionSuccessCallbackFunction) {
        this.sessionSuccessCallbackFunction(sessionSuccess);
    }
};

AdjustConfig.prototype.setSessionFailureCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.sessionFailureCallbackName = callback;
    } else {
        this.sessionFailureCallbackName = 'Adjust.getConfig().adjust_sessionFailureCallback';
        this.sessionFailureCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_sessionFailureCallback = function(sessionFailure) {
    if (this.sessionFailureCallbackFunction) {
        this.sessionFailureCallbackFunction(sessionFailure);
    }
};

AdjustConfig.prototype.disableDeferredDeeplinkOpening = function() {
    this.isOpeningDeferredDeeplinkEnabled = false;
};

AdjustConfig.prototype.setDeferredDeeplinkCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.deferredDeeplinkCallbackName = callback;
    } else {
        this.deferredDeeplinkCallbackName = 'Adjust.getConfig().adjust_deferredDeeplinkCallback';
        this.deferredDeeplinkCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_deferredDeeplinkCallback = function(deeplink) {
    if (this.deferredDeeplinkCallbackFunction) {
        this.deferredDeeplinkCallbackFunction(deeplink);
    }
};

AdjustConfig.prototype.setRemoteTriggerCallback = function(callback) {
    if (typeof callback === 'string' || callback instanceof String) {
        this.remoteTriggerCallbackName = callback;
    } else {
        this.remoteTriggerCallbackName = 'Adjust.getConfig().adjust_remoteTriggerCallback';
        this.remoteTriggerCallbackFunction = callback;
    }
};

AdjustConfig.prototype.adjust_remoteTriggerCallback = function(remoteTrigger) {
    if (this.remoteTriggerCallbackFunction) {
        this.remoteTriggerCallbackFunction(remoteTrigger);
    }
};

AdjustConfig.prototype.setReadMobileEquipmentIdentity = function(readMobileEquipmentIdentity) {};

AdjustConfig.prototype.setFbPixelDefaultEventToken = function(fbPixelDefaultEventToken) {
    this.fbPixelDefaultEventToken = fbPixelDefaultEventToken;
};

AdjustConfig.prototype.addFbPixelMapping = function(fbEventNameKey, adjEventTokenValue) {
    this.fbPixelMapping.push(fbEventNameKey);
    this.fbPixelMapping.push(adjEventTokenValue);
};

AdjustConfig.prototype.setUrlStrategy = function(urlStrategyDomains, useSubdomains , isDataResidency) {
    this.urlStrategyDomains = urlStrategyDomains;
    this.useSubdomains = useSubdomains;
    this.isDataResidency = isDataResidency;
};

AdjustConfig.prototype.enablePreinstallTracking = function() {
    this.isPreinstallTrackingEnabled = true;
};

AdjustConfig.prototype.setPreinstallFilePath = function(preinstallFilePath) {
    this.preinstallFilePath = preinstallFilePath;
};

AdjustConfig.prototype.enableCoppaCompliance = function() {
     this.coppaComplianceEnabled = true;
};

AdjustConfig.prototype.enablePlayStoreKidsCompliance = function() {
     this.playStoreKidsComplianceEnabled = true;
};

AdjustConfig.prototype.setFbAppId = function(fbAppId) {
    this.fbAppId = fbAppId;
};

AdjustConfig.prototype.readDeviceIdsOnce = function() {
    this.shouldReadDeviceIdsOnce = true;
};

AdjustConfig.prototype.setEventDeduplicationIdsMaxSize = function(eventDeduplicationIdsMaxSize) {
    this.eventDeduplicationIdsMaxSize = eventDeduplicationIdsMaxSize;
};

AdjustConfig.prototype.enableFirstSessionDelay = function() {
    this.isFirstSessionDelayEnabled = true;
};

AdjustConfig.prototype.setStoreInfo = function(storeInfo) {
    this.storeInfo = JSON.stringify(storeInfo);
};

AdjustConfig.prototype.disableGoogleAdIdReading = function() {
    this.isGoogleAdIdReadingEnabled = false;
};

AdjustConfig.prototype.disableAndroidIdReading = function() {
    this.isAndroidIdReadingEnabled = false;
};

AdjustConfig.prototype.disableAppSetIdReading = function() {
    this.isAppSetIdReadingEnabled = false;
};

AdjustConfig.prototype.disableFbIdReading = function() {
    this.isFbIdReadingEnabled = false;
};

AdjustConfig.prototype.disableFireAdIdReading = function() {
    this.isFireAdIdReadingEnabled = false;
};

AdjustConfig.prototype.disableDeviceIdsFromPluginsReading = function() {
    this.isDeviceIdsFromPluginsReadingEnabled = false;
};

AdjustConfig.prototype.disableDeviceIdsReading = function() {
    this.isGoogleAdIdReadingEnabled = false;
    this.isAndroidIdReadingEnabled = false;
    this.isAppSetIdReadingEnabled = false;
    this.isFbIdReadingEnabled = false;
    this.isFireAdIdReadingEnabled = false;
    this.isDeviceIdsFromPluginsReadingEnabled = false;
};
